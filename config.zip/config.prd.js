'use strict';

define(function() {
  return {
    apps: [{
      id: 474495017,
      name: 'ing',
      dashboard: {
        specialUsers: ['Sjoerdvo', 'Jaap Leving', 'MOTABEATZ', 'Coprene', 'Hyper72xx', 'Jeroen Prins'],
        keywords: ['(nooit)? problemen', '(nooit)? storingen', '(erg|zeer|dik)? ?tevreden', 'reclame', 'start .* niet .* meer (op)?', 'scanner', 'QR', 'acceptgiro([a-zA-Z])*', 'vingerafdruk', 'fingerprint', 'letter( )?type', 'font', '(ge)?makkelijk(er)?', 'Apple pay', '(gebruiks)?vriendelijk(heid)?', 'Nu nog', '(alleen )?mis ik( nog)?', 'geweldig(e)?( app)?', '(fijne|super|goede) app', 'werkt goed', 'na .* update', 'veilig', 'veiligheid', 'overzichtelijk(er)?', 'ziet .* er .* beter uit', '(super )?simpel', 'complimenten']
      },
      cloud: {
        irrelevant: ['ing', 'de', 'het', 'een', 'met', 'ook', 'voor', 'van', 'alle', 'mee', 'wordt', 'word', 'geen', 'erg', 'wat', 'zou', 'heel', 'die', 'nooit', 'bij', 'over', 'als', 'ben', 'echt', 'nog', 'dat', 'app', 'apps', 'aan', 'the', 'dan', 'door', 'iphone', 'deze', 'use', 'staat', 'maak', 'kan', 'maar', 'kunnen', 'mijn', 'zeer', 'gaat', 'heb', 'ik', 'mij', 'and', 'zijn', 'werkt', 'hij', 'rabobank', 'abn', 'dit', 'zit', 'hebt', 'daar', 'via', 'uit', 'wel', 'was', 'vind', 'daarnaast', 'moet', 'maken', 'naar', 'eens', 'zoal', 'hier', 'terwijl', 'ten', 'net', 'kom', 'wil'],
        synonyms: {
          font: 'lettertype',
          rabobank: 'rabo'
        }
      }
    }, {
      id: 1058444677,
      name: 'twyp'
    }, {
      id: 346790636,
      name: 'rabobank'
    }, {
      id: 439728011,
      name: 'abnamro'
    }, {
      id: 431068189,
      name: 'sns'
    }, {
      id: 1021178150,
      name: 'bunq'
    }],
    defaults: {
      language: 'nl'
    }
  };
});
